"""Async version of MDCSTAT300 data fetcher."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

import pandas as pd

from .async_client import AsyncKRXClient


def _normalize_yyyymmdd(value: str | date | datetime) -> str:
    if isinstance(value, datetime):
        return value.strftime("%Y%m%d")
    if isinstance(value, date):
        return value.strftime("%Y%m%d")

    s = value.strip()
    if len(s) == 8 and s.isdigit():
        return s
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%Y%m%d")
    except ValueError as exc:
        raise ValueError("Date must be YYYYMMDD or YYYY-MM-DD") from exc


def _pick_table(data: dict[str, Any]) -> list[dict[str, Any]]:
    # KRX commonly returns table-like data in OutBlock_1/output/data keys.
    for key in ("OutBlock_1", "output", "block1", "result"):
        value = data.get(key)
        if isinstance(value, list) and all(isinstance(row, dict) for row in value):
            return value

    for value in data.values():
        if isinstance(value, list) and all(isinstance(row, dict) for row in value):
            return value

    raise ValueError(f"No table-like list found in response keys={list(data.keys())}")


async def fetch_mdcstat300_async(
    *,
    isu_cd: str,
    start_date: str | date | datetime,
    end_date: str | date | datetime,
    bld: str,
    screen_id: str = "MDCSTAT300",
    extra_payload: dict[str, Any] | None = None,
    proxy: str | None = None,
    proxy_auth: tuple[str, str] | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Async fetch KRX MDCSTAT300 data with optional proxy.

    Args:
        isu_cd: 12-digit standard code (e.g., "KR7033640004")
        start_date: Start date
        end_date: End date
        bld: KRX bld parameter (e.g., "dbms/MDC_OUT/STAT/srt/MDCSTAT30001_OUT")
        screen_id: Screen ID (default: "MDCSTAT300")
        extra_payload: Additional payload parameters
        proxy: Proxy URL (e.g., "http://proxy.example.com:8080")
        proxy_auth: Proxy authentication (username, password)

    Returns:
        (DataFrame, raw_json)
    """
    payload: dict[str, Any] = {
        "isuCd": isu_cd,
        "strtDd": _normalize_yyyymmdd(start_date),
        "endDd": _normalize_yyyymmdd(end_date),
        "share": "1",
        "money": "1",
        "csvxls_isNo": "false",
    }
    if extra_payload:
        payload.update(extra_payload)

    async with AsyncKRXClient(proxy=proxy, proxy_auth=proxy_auth) as client:
        await client.warmup(screen_id=screen_id, isu_cd=isu_cd)
        raw = await client.post_json(bld=bld, payload=payload)

    rows = _pick_table(raw)
    df = pd.DataFrame(rows)
    return df, raw
