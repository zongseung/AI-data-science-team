from __future__ import annotations

from datetime import date, datetime
from typing import Any

import pandas as pd

from .client import KRXClient


def _normalize_yyyymmdd(value: str | date | datetime) -> str:
    if isinstance(value, datetime):
        return value.strftime("%Y%m%d")
    if isinstance(value, date):
        return value.strftime("%Y%m%d")

    s = value.strip()
    if len(s) == 8 and s.isdigit():
        return s
    try:
        return datetime.strptime(s, "%Y-%m-%d").strftime("%Y%m%d")
    except ValueError as exc:
        raise ValueError("Date must be YYYYMMDD or YYYY-MM-DD") from exc


def _pick_table(data: dict[str, Any]) -> list[dict[str, Any]]:
    # KRX commonly returns table-like data in OutBlock_1/output/data keys.
    for key in ("OutBlock_1", "output", "block1", "result"):
        value = data.get(key)
        if isinstance(value, list) and all(isinstance(row, dict) for row in value):
            return value

    for value in data.values():
        if isinstance(value, list) and all(isinstance(row, dict) for row in value):
            return value

    raise ValueError(f"No table-like list found in response keys={list(data.keys())}")


def fetch_mdcstat300(
    *,
    isu_cd: str,
    start_date: str | date | datetime,
    end_date: str | date | datetime,
    bld: str,
    screen_id: str = "MDCSTAT300",
    extra_payload: dict[str, Any] | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Fetch KRX MDCSTAT300 data and return (DataFrame, raw_json)."""
    payload: dict[str, Any] = {
        "isuCd": isu_cd,
        "strtDd": _normalize_yyyymmdd(start_date),
        "endDd": _normalize_yyyymmdd(end_date),
        "share": "1",
        "money": "1",
        "csvxls_isNo": "false",
    }
    if extra_payload:
        payload.update(extra_payload)

    with KRXClient() as client:
        client.warmup(screen_id=screen_id, isu_cd=isu_cd)
        raw = client.post_json(bld=bld, payload=payload)

    rows = _pick_table(raw)
    df = pd.DataFrame(rows)
    return df, raw
